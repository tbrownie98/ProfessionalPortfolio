﻿namespace Program1
{
    partial class Program1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.squareFeetOfWallToPaintLabel = new System.Windows.Forms.Label();
            this.priceOfPaintPerGallonLabel = new System.Windows.Forms.Label();
            this.numberOfGallonsOfPaintRequiredLabel = new System.Windows.Forms.Label();
            this.hoursOfLaborLabel = new System.Windows.Forms.Label();
            this.costOfPaintLabel = new System.Windows.Forms.Label();
            this.squareFeetInputTextBox = new System.Windows.Forms.TextBox();
            this.pricePerGallonInputTextBox = new System.Windows.Forms.TextBox();
            this.numberOfCoatsLabel = new System.Windows.Forms.Label();
            this.totalSquareFeetToPaintLabel = new System.Windows.Forms.Label();
            this.totalSquareFeetOutputLabel = new System.Windows.Forms.Label();
            this.numberOfGallonsRequiredOutputLabel = new System.Windows.Forms.Label();
            this.hoursOfLaborOutputLabel = new System.Windows.Forms.Label();
            this.costOfPaintOutputLabel = new System.Windows.Forms.Label();
            this.costOfLaborLabel = new System.Windows.Forms.Label();
            this.numberOfCoatsInputTextBox = new System.Windows.Forms.TextBox();
            this.calculateTotalCostButton = new System.Windows.Forms.Button();
            this.costOfLaborOutputLabel = new System.Windows.Forms.Label();
            this.totalCostOfJobOutputLabel = new System.Windows.Forms.Label();
            this.totalCostOfJobLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.lineLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // squareFeetOfWallToPaintLabel
            // 
            this.squareFeetOfWallToPaintLabel.AutoSize = true;
            this.squareFeetOfWallToPaintLabel.Location = new System.Drawing.Point(1, 75);
            this.squareFeetOfWallToPaintLabel.Name = "squareFeetOfWallToPaintLabel";
            this.squareFeetOfWallToPaintLabel.Size = new System.Drawing.Size(250, 13);
            this.squareFeetOfWallToPaintLabel.TabIndex = 0;
            this.squareFeetOfWallToPaintLabel.Text = "Enter Number of Square Feet of Wall to be Painted:";
            // 
            // priceOfPaintPerGallonLabel
            // 
            this.priceOfPaintPerGallonLabel.AutoSize = true;
            this.priceOfPaintPerGallonLabel.Location = new System.Drawing.Point(99, 120);
            this.priceOfPaintPerGallonLabel.Name = "priceOfPaintPerGallonLabel";
            this.priceOfPaintPerGallonLabel.Size = new System.Drawing.Size(152, 13);
            this.priceOfPaintPerGallonLabel.TabIndex = 1;
            this.priceOfPaintPerGallonLabel.Text = "Enter Price of Paint per Gallon:";
            // 
            // numberOfGallonsOfPaintRequiredLabel
            // 
            this.numberOfGallonsOfPaintRequiredLabel.AutoSize = true;
            this.numberOfGallonsOfPaintRequiredLabel.Location = new System.Drawing.Point(69, 182);
            this.numberOfGallonsOfPaintRequiredLabel.Name = "numberOfGallonsOfPaintRequiredLabel";
            this.numberOfGallonsOfPaintRequiredLabel.Size = new System.Drawing.Size(182, 13);
            this.numberOfGallonsOfPaintRequiredLabel.TabIndex = 2;
            this.numberOfGallonsOfPaintRequiredLabel.Text = "Number of Gallons of Paint Required:";
            // 
            // hoursOfLaborLabel
            // 
            this.hoursOfLaborLabel.AutoSize = true;
            this.hoursOfLaborLabel.Location = new System.Drawing.Point(125, 204);
            this.hoursOfLaborLabel.Name = "hoursOfLaborLabel";
            this.hoursOfLaborLabel.Size = new System.Drawing.Size(126, 13);
            this.hoursOfLaborLabel.TabIndex = 3;
            this.hoursOfLaborLabel.Text = "Hours of Labor Required:";
            // 
            // costOfPaintLabel
            // 
            this.costOfPaintLabel.AutoSize = true;
            this.costOfPaintLabel.Location = new System.Drawing.Point(181, 226);
            this.costOfPaintLabel.Name = "costOfPaintLabel";
            this.costOfPaintLabel.Size = new System.Drawing.Size(70, 13);
            this.costOfPaintLabel.TabIndex = 4;
            this.costOfPaintLabel.Text = "Cost of Paint:";
            // 
            // squareFeetInputTextBox
            // 
            this.squareFeetInputTextBox.Location = new System.Drawing.Point(257, 72);
            this.squareFeetInputTextBox.Name = "squareFeetInputTextBox";
            this.squareFeetInputTextBox.Size = new System.Drawing.Size(100, 20);
            this.squareFeetInputTextBox.TabIndex = 5;
            // 
            // pricePerGallonInputTextBox
            // 
            this.pricePerGallonInputTextBox.Location = new System.Drawing.Point(257, 117);
            this.pricePerGallonInputTextBox.Name = "pricePerGallonInputTextBox";
            this.pricePerGallonInputTextBox.Size = new System.Drawing.Size(100, 20);
            this.pricePerGallonInputTextBox.TabIndex = 6;
            // 
            // numberOfCoatsLabel
            // 
            this.numberOfCoatsLabel.AutoSize = true;
            this.numberOfCoatsLabel.Location = new System.Drawing.Point(95, 98);
            this.numberOfCoatsLabel.Name = "numberOfCoatsLabel";
            this.numberOfCoatsLabel.Size = new System.Drawing.Size(156, 13);
            this.numberOfCoatsLabel.TabIndex = 7;
            this.numberOfCoatsLabel.Text = "Enter Number of Coats Desired:";
            // 
            // totalSquareFeetToPaintLabel
            // 
            this.totalSquareFeetToPaintLabel.AutoSize = true;
            this.totalSquareFeetToPaintLabel.Location = new System.Drawing.Point(90, 160);
            this.totalSquareFeetToPaintLabel.Name = "totalSquareFeetToPaintLabel";
            this.totalSquareFeetToPaintLabel.Size = new System.Drawing.Size(161, 13);
            this.totalSquareFeetToPaintLabel.TabIndex = 8;
            this.totalSquareFeetToPaintLabel.Text = "Total Square Feet to be Painted:";
            // 
            // totalSquareFeetOutputLabel
            // 
            this.totalSquareFeetOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalSquareFeetOutputLabel.Location = new System.Drawing.Point(257, 158);
            this.totalSquareFeetOutputLabel.Name = "totalSquareFeetOutputLabel";
            this.totalSquareFeetOutputLabel.Size = new System.Drawing.Size(100, 15);
            this.totalSquareFeetOutputLabel.TabIndex = 9;
            // 
            // numberOfGallonsRequiredOutputLabel
            // 
            this.numberOfGallonsRequiredOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberOfGallonsRequiredOutputLabel.Location = new System.Drawing.Point(257, 180);
            this.numberOfGallonsRequiredOutputLabel.Name = "numberOfGallonsRequiredOutputLabel";
            this.numberOfGallonsRequiredOutputLabel.Size = new System.Drawing.Size(100, 15);
            this.numberOfGallonsRequiredOutputLabel.TabIndex = 10;
            // 
            // hoursOfLaborOutputLabel
            // 
            this.hoursOfLaborOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hoursOfLaborOutputLabel.Location = new System.Drawing.Point(257, 202);
            this.hoursOfLaborOutputLabel.Name = "hoursOfLaborOutputLabel";
            this.hoursOfLaborOutputLabel.Size = new System.Drawing.Size(100, 15);
            this.hoursOfLaborOutputLabel.TabIndex = 11;
            // 
            // costOfPaintOutputLabel
            // 
            this.costOfPaintOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.costOfPaintOutputLabel.Location = new System.Drawing.Point(257, 224);
            this.costOfPaintOutputLabel.Name = "costOfPaintOutputLabel";
            this.costOfPaintOutputLabel.Size = new System.Drawing.Size(100, 15);
            this.costOfPaintOutputLabel.TabIndex = 12;
            // 
            // costOfLaborLabel
            // 
            this.costOfLaborLabel.AutoSize = true;
            this.costOfLaborLabel.Location = new System.Drawing.Point(178, 248);
            this.costOfLaborLabel.Name = "costOfLaborLabel";
            this.costOfLaborLabel.Size = new System.Drawing.Size(73, 13);
            this.costOfLaborLabel.TabIndex = 13;
            this.costOfLaborLabel.Text = "Cost of Labor:";
            // 
            // numberOfCoatsInputTextBox
            // 
            this.numberOfCoatsInputTextBox.Location = new System.Drawing.Point(257, 95);
            this.numberOfCoatsInputTextBox.Name = "numberOfCoatsInputTextBox";
            this.numberOfCoatsInputTextBox.Size = new System.Drawing.Size(100, 20);
            this.numberOfCoatsInputTextBox.TabIndex = 14;
            // 
            // calculateTotalCostButton
            // 
            this.calculateTotalCostButton.AutoSize = true;
            this.calculateTotalCostButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateTotalCostButton.Location = new System.Drawing.Point(71, 324);
            this.calculateTotalCostButton.Name = "calculateTotalCostButton";
            this.calculateTotalCostButton.Size = new System.Drawing.Size(244, 26);
            this.calculateTotalCostButton.TabIndex = 15;
            this.calculateTotalCostButton.Text = "Calculate Total Cost of Paint Job";
            this.calculateTotalCostButton.UseVisualStyleBackColor = true;
            // 
            // costOfLaborOutputLabel
            // 
            this.costOfLaborOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.costOfLaborOutputLabel.Location = new System.Drawing.Point(257, 246);
            this.costOfLaborOutputLabel.Name = "costOfLaborOutputLabel";
            this.costOfLaborOutputLabel.Size = new System.Drawing.Size(100, 15);
            this.costOfLaborOutputLabel.TabIndex = 16;
            // 
            // totalCostOfJobOutputLabel
            // 
            this.totalCostOfJobOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCostOfJobOutputLabel.Location = new System.Drawing.Point(257, 284);
            this.totalCostOfJobOutputLabel.Name = "totalCostOfJobOutputLabel";
            this.totalCostOfJobOutputLabel.Size = new System.Drawing.Size(100, 15);
            this.totalCostOfJobOutputLabel.TabIndex = 17;
            // 
            // totalCostOfJobLabel
            // 
            this.totalCostOfJobLabel.AutoSize = true;
            this.totalCostOfJobLabel.Location = new System.Drawing.Point(134, 286);
            this.totalCostOfJobLabel.Name = "totalCostOfJobLabel";
            this.totalCostOfJobLabel.Size = new System.Drawing.Size(117, 13);
            this.totalCostOfJobLabel.TabIndex = 18;
            this.totalCostOfJobLabel.Text = "Total Cost of Paint Job:";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(8, 20);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(370, 31);
            this.titleLabel.TabIndex = 19;
            this.titleLabel.Text = "Cost of Paint Job Estimator";
            // 
            // lineLabel
            // 
            this.lineLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lineLabel.Location = new System.Drawing.Point(68, 261);
            this.lineLabel.Name = "lineLabel";
            this.lineLabel.Size = new System.Drawing.Size(306, 23);
            this.lineLabel.TabIndex = 20;
            this.lineLabel.Text = "                                                                                 " +
    "                       ";
            // 
            // Program1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(383, 360);
            this.Controls.Add(this.lineLabel);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.totalCostOfJobLabel);
            this.Controls.Add(this.totalCostOfJobOutputLabel);
            this.Controls.Add(this.costOfLaborOutputLabel);
            this.Controls.Add(this.calculateTotalCostButton);
            this.Controls.Add(this.numberOfCoatsInputTextBox);
            this.Controls.Add(this.costOfLaborLabel);
            this.Controls.Add(this.costOfPaintOutputLabel);
            this.Controls.Add(this.hoursOfLaborOutputLabel);
            this.Controls.Add(this.numberOfGallonsRequiredOutputLabel);
            this.Controls.Add(this.totalSquareFeetOutputLabel);
            this.Controls.Add(this.totalSquareFeetToPaintLabel);
            this.Controls.Add(this.numberOfCoatsLabel);
            this.Controls.Add(this.pricePerGallonInputTextBox);
            this.Controls.Add(this.squareFeetInputTextBox);
            this.Controls.Add(this.costOfPaintLabel);
            this.Controls.Add(this.hoursOfLaborLabel);
            this.Controls.Add(this.numberOfGallonsOfPaintRequiredLabel);
            this.Controls.Add(this.priceOfPaintPerGallonLabel);
            this.Controls.Add(this.squareFeetOfWallToPaintLabel);
            this.Name = "Program1";
            this.Text = "Program 1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label squareFeetOfWallToPaintLabel;
        private System.Windows.Forms.Label priceOfPaintPerGallonLabel;
        private System.Windows.Forms.Label numberOfGallonsOfPaintRequiredLabel;
        private System.Windows.Forms.Label hoursOfLaborLabel;
        private System.Windows.Forms.Label costOfPaintLabel;
        private System.Windows.Forms.TextBox squareFeetInputTextBox;
        private System.Windows.Forms.TextBox pricePerGallonInputTextBox;
        private System.Windows.Forms.Label numberOfCoatsLabel;
        private System.Windows.Forms.Label totalSquareFeetToPaintLabel;
        private System.Windows.Forms.Label totalSquareFeetOutputLabel;
        private System.Windows.Forms.Label numberOfGallonsRequiredOutputLabel;
        private System.Windows.Forms.Label hoursOfLaborOutputLabel;
        private System.Windows.Forms.Label costOfPaintOutputLabel;
        private System.Windows.Forms.Label costOfLaborLabel;
        private System.Windows.Forms.TextBox numberOfCoatsInputTextBox;
        private System.Windows.Forms.Button calculateTotalCostButton;
        private System.Windows.Forms.Label costOfLaborOutputLabel;
        private System.Windows.Forms.Label totalCostOfJobOutputLabel;
        private System.Windows.Forms.Label totalCostOfJobLabel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label lineLabel;
    }
}

