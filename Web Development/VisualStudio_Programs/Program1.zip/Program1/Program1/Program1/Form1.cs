﻿//Grading ID: B6295
//Program #: Program1
//Due Date: 09/27/2016
//Course: CIS199-75
//Description: Program1 is a tool that helps painters figure their total costs for a job and can show the customer what exactly
//             they are paying for. So, this is essentially a complex calculator. It takes the user's inputs of square of wall
//             to be painted, number of coats, and the price per gallon of paint and uses these to calculate all of the costs
//             that are associated with completing the paint job.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Program1 : Form
    {

        public Program1()
        {
            InitializeComponent();
        }
                    //Clicking the button in the form executes the following calculations to show results from user's inputs.
        private void calculateTotalCostButton_Click(object sender, EventArgs e)
        {
                    //Sets "magic numbers" to named constants to assist in calculations.
            const float
                squareFeet = 275F,
                hoursOfLabor = 8F,
                costPerHourLabor = 12.50F;

                    //Assigns a double keyword to local variable to simplify the following equations.
            int
                numberOfCoats;

                    //Assigns a double keyword to local variable to simplify the following equations.
            double
                totalSquareFeetRequired,
                numberOfGallonsRequired,
                hoursOfLaborRequired,
                costOfPaint,
                costOfLabor,
                totalCostOfJob;

                    //Assigns a float keyword to local variables to simplify the following equations.
            float
                squareFeetDesired,
                pricePerGallon;

                    //Gets the user's input for Square Feet of Wall to be Painted.
            squareFeetDesired = float.Parse(squareFeetInputTextBox.Text);
                    //Gets the user's input for Number of Coats Desired.
            numberOfCoats = int.Parse(numberOfCoatsInputTextBox.Text);
                    //Gets the user's input for Price of Paint per Gallon.
            pricePerGallon = float.Parse(pricePerGallonInputTextBox.Text);

                    //Calculates the total Square Feet of Wall to complete job.
            totalSquareFeetRequired = squareFeetDesired * numberOfCoats;
                    //Calculates the Number of Gallons of Paint to complete job.
            numberOfGallonsRequired = Math.Ceiling(totalSquareFeetRequired / squareFeet);
                    //Calculates the Hours of Labor Required to complete job.
            hoursOfLaborRequired = (totalSquareFeetRequired / squareFeet) * hoursOfLabor;
                    //Calculates the Total Cost of Paint to complete job.
            costOfPaint = pricePerGallon * numberOfGallonsRequired;
                    //Calculates the Total Cost of Labor to complete job.
            costOfLabor = hoursOfLaborRequired * costPerHourLabor;
                    //Calculates the Total Cost for job.
            totalCostOfJob = costOfPaint + costOfLabor;

                    //Displays the total Square Feet of Wall of job.
            totalSquareFeetOutputLabel.Text = totalSquareFeetRequired.ToString("f1") + " sq. ft.";
                    //Displays the Number of Gallons of Paint of job.
            numberOfGallonsRequiredOutputLabel.Text = numberOfGallonsRequired.ToString("n0") + " gal";
                    //Displays the Hours of Labor Required of job.
            hoursOfLaborOutputLabel.Text = hoursOfLaborRequired.ToString("n1") + " hours";
                    //Displays the Total Cost of Paint of job.
            costOfPaintOutputLabel.Text = costOfPaint.ToString("c");
                    //Displays the Total Cost of Labor of job.
            costOfLaborOutputLabel.Text = costOfLabor.ToString("c");
                    //Displays the Total Cost of Paint Job.
            totalCostOfJobOutputLabel.Text = totalCostOfJob.ToString("c");
        }
    }
}
