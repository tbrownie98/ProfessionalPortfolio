﻿namespace Program2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleLabel = new System.Windows.Forms.Label();
            this.creditHoursLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.registrationTimeLabel = new System.Windows.Forms.Label();
            this.rDateTimeOutputLabel = new System.Windows.Forms.Label();
            this.hoursTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.lineLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(12, -4);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(268, 48);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Find your registration date and time!";
            this.titleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // creditHoursLabel
            // 
            this.creditHoursLabel.AutoSize = true;
            this.creditHoursLabel.Location = new System.Drawing.Point(25, 53);
            this.creditHoursLabel.Name = "creditHoursLabel";
            this.creditHoursLabel.Size = new System.Drawing.Size(149, 13);
            this.creditHoursLabel.TabIndex = 1;
            this.creditHoursLabel.Text = "Enter Completed Credit Hours:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(85, 79);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(89, 13);
            this.lastNameLabel.TabIndex = 2;
            this.lastNameLabel.Text = "Enter Last Name:";
            // 
            // registrationTimeLabel
            // 
            this.registrationTimeLabel.AutoSize = true;
            this.registrationTimeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.registrationTimeLabel.Location = new System.Drawing.Point(77, 142);
            this.registrationTimeLabel.Name = "registrationTimeLabel";
            this.registrationTimeLabel.Size = new System.Drawing.Size(139, 13);
            this.registrationTimeLabel.TabIndex = 8;
            this.registrationTimeLabel.Text = "Registration Date and Time:";
            // 
            // rDateTimeOutputLabel
            // 
            this.rDateTimeOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rDateTimeOutputLabel.Location = new System.Drawing.Point(50, 157);
            this.rDateTimeOutputLabel.Name = "rDateTimeOutputLabel";
            this.rDateTimeOutputLabel.Size = new System.Drawing.Size(192, 15);
            this.rDateTimeOutputLabel.TabIndex = 9;
            this.rDateTimeOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hoursTextBox
            // 
            this.hoursTextBox.Location = new System.Drawing.Point(180, 50);
            this.hoursTextBox.Name = "hoursTextBox";
            this.hoursTextBox.Size = new System.Drawing.Size(100, 20);
            this.hoursTextBox.TabIndex = 3;
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(180, 76);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 4;
            // 
            // lineLabel
            // 
            this.lineLabel.AutoSize = true;
            this.lineLabel.Location = new System.Drawing.Point(2, 120);
            this.lineLabel.Name = "lineLabel";
            this.lineLabel.Size = new System.Drawing.Size(289, 13);
            this.lineLabel.TabIndex = 7;
            this.lineLabel.Text = "_______________________________________________";
            // 
            // calculateButton
            // 
            this.calculateButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.calculateButton.Location = new System.Drawing.Point(177, 102);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 5;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(40, 102);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 6;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // Program2
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 181);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.lineLabel);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.hoursTextBox);
            this.Controls.Add(this.rDateTimeOutputLabel);
            this.Controls.Add(this.registrationTimeLabel);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.creditHoursLabel);
            this.Controls.Add(this.titleLabel);
            this.Name = "Program2";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label creditHoursLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label registrationTimeLabel;
        private System.Windows.Forms.Label rDateTimeOutputLabel;
        private System.Windows.Forms.TextBox hoursTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label lineLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button resetButton;
    }
}

