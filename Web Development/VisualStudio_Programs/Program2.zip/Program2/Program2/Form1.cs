﻿//Grading ID: B6295
//Program #: 2
//Section: CIS199-75
//Due Date: 10/16/2016
//Description: This program gathers the user's input of completed credit hours & the user's last name. It takes this criteria and displays
//             the appropiate Registration date and time for the user's class, based on completed credit hours & displays the date, & the user's 
//             first character of their last name for the time, which displays the time of registration.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Program2 : Form
    {
        //Registration Dates
        public string r_Date; //Assigns r_Date to string type & is the output Registration Date.
        public const string SENIOR_DATE = "Friday, November 4", //Assigns SENIOR_DATE field to string type for Senior date for registration.
                            JUNIOR_DATE = "Monday, November 7", //Assigns JUNIOR_DATE field to string type for Junior date for registration.
                            SOPH_DATE1 = "Wednesday, November 9", //Assigns SOPH_DATE1 field to string type for 1st Sophmore date for registration.
                            SOPH_DATE2 = "Thursday, November 10", //Assigns SOPH_DATE2 field to string type for 2nd Sophmore date for registration.
                            FRESH_DATE1 = "Friday, November 11", //Assigns FRESH_DATE field to string type for 1st Freshman date for registration.
                            FRESH_DATE2 = "Monday, November 14"; //Assigns FRESH_DATE field to string type for 2nd Freshman date for registration.

        //Registration Times
        public string r_Time; //Assigns r_Time to string type & is the output Registration Time.
        public const string R_TIME1 = "8:30 AM", //Assigns R_TIME1 field to string type for 1st Registraton time.
                            R_TIME2 = "10:00 AM", //Assigns R_TIME2 field to string type for 2nd Registraton time.
                            R_TIME3 = "11:30 AM", //Assigns R_TIME3 field to string type for 3rd Registraton time.
                            R_TIME4 = "2:00 PM", //Assigns R_TIME4 field to string type for 4th Registraton time.
                            R_TIME5 = "4:00 PM"; //Assigns R_TIME5 field to string type for 5th Registraton time.

        //Class Credit Hours
        public const int SENIOR_HOURS = 90; //Assigns constant SENIOR_HOURS to "magic number" 90.
        public const int JUNIOR_HOURS = 60; //Assigns constant JUNIOR_HOURS to "magic number" 60.
        public const int SOPH_HOURS = 30; //Assigns constant SOPH_HOURS to "magic number" 30.
        public const int FRESH_HOURS = 0; //Assigns constant FRESH_HOURS to "magic number" 0.

        public Program2()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double credit_hours; //Assings credit_hours to double floating-point type.
            string last_name = nameTextBox.Text; //Assigns nameTextBox input to last_name string local variable.
            char first_char = last_name[0]; //Assigns the first character of last_name, from nameTextBox input, to first_char variable.
            char upper_char = char.ToUpper(first_char); //Assigns character data type to letter local variable & selects first charcter in the last_name string.

            if (double.TryParse(hoursTextBox.Text, out credit_hours)) //Checks input for credithoursTextBox is a number.
            {
                if (char.IsLetter(last_name[0])) //Makes sure last_name's first char is a letter and not a number.
                {
                    //Senior & Junior Registration Criteria
                    if (credit_hours >= JUNIOR_HOURS)
                    {
                        if (credit_hours >= SENIOR_HOURS) //IF statement for Senior hours to assign correct date.
                            r_Date = SENIOR_DATE;
                        else//ELSE statement for Junior hours to assign correct date.
                            r_Date = JUNIOR_DATE;
                        if (upper_char >= 'A' && upper_char <= 'D') //Assigns A-D characters to 2:00PM time.
                            r_Time = R_TIME4;
                        else if (upper_char >= 'E' && upper_char <= 'I') //Assigns E-I characters to 4:00PM time.
                            r_Time = R_TIME5;
                        else if (upper_char >= 'J' && upper_char <= 'O') //Assigns J-O characters to 8:30AM time.
                            r_Time = R_TIME1;
                        else if (upper_char >= 'P' && upper_char <= 'S') //Assigns P-S characters to 10:00AM time.
                            r_Time = R_TIME2;
                        else //Assigns T-Z characters to 11:30AM time.
                            r_Time = R_TIME3;
                    }
                    //Sophmore and Freshman Registration Criteria
                    else if (credit_hours >= FRESH_HOURS)
                    {
                        if (credit_hours >= SOPH_HOURS && credit_hours < JUNIOR_HOURS) //IF statement for Sophmore hours to assign correct date.
                        {
                            if ((upper_char >= 'A' && upper_char <= 'I') || upper_char >= 'W') //IF statement for Sophmore hours with A-I & W-Z characters to assign correct date.
                                r_Date = SOPH_DATE2;
                            else //ELSE statement for Sophmore hours with J-V characters to assign correct date.
                                r_Date = SOPH_DATE1;
                        }
                        else if ((upper_char >= 'A' && upper_char <= 'I') || upper_char >= 'W') //IF statement for Freshman hours with A-I & W-Z characters to assign correct date.
                            r_Date = FRESH_DATE2;
                        else //ELSE statement for Freshman hours with J-V character to assign correct date.
                            r_Date = FRESH_DATE1;
                        if ((upper_char >= 'A' && upper_char <= 'B') || (upper_char >= 'M' && upper_char <= 'O')) //Assigns 10:00AM time to A-B & M-O characters for Sophmore and Freshman classes.
                            r_Time = R_TIME2;
                        else if ((upper_char >= 'C' && upper_char <= 'D') || (upper_char >= 'P' && upper_char <= 'Q')) //Assigns 11:30AM time to C-D & P-Q characters for Sophmore and Freshman classes.
                            r_Time = R_TIME3;
                        else if ((upper_char >= 'E' && upper_char <= 'F') || (upper_char >= 'R' && upper_char <= 'S')) //Assigns 2:00PM time to E-F & R-S characters for Sophmore and Freshman classes.
                            r_Time = R_TIME4;
                        else if ((upper_char >= 'G' && upper_char <= 'I') || (upper_char >= 'T' && upper_char <= 'V')) //Assigns 4:00PM time to G-I & T-V characters for Sophmore and Freshman classes.
                            r_Time = R_TIME5;
                        else if ((upper_char >= 'J' && upper_char <= 'L') || (upper_char >= 'W' && upper_char <= 'Z')) //Assigns 8:00AM time to J-L & W-Z characters for Sophmore and Freshman classes.
                            r_Time = R_TIME1;
                    }
                    else
                        MessageBox.Show("Enter a valid number of Credit Hours!");

                    rDateTimeOutputLabel.Text = (r_Date + " @ " + r_Time); //Creates the output registration date and time label.
                }
                else
                    MessageBox.Show("Enter a valid Last Name!"); //If nameTextBox is not in the right type/form, this messagebox will appear.
            }
            else
                MessageBox.Show("Enter a valid number of Credit Hours!"); //If credithoursTextBox is not in the right type/form, this messagebox will appear.   
            }

    private void resetButton_Click(object sender, EventArgs e) //Clears input TextBoxes and output Label to allow a blank form and new entries to be entered.
        {
            //Clear TextBoxes and Registration Output Label controls.
            hoursTextBox.Text = "";
            nameTextBox.Text = "";
            rDateTimeOutputLabel.Text = "";

            //Reset the focus to hoursTextbox.
            hoursTextBox.Focus();
        }

        }
    }
                    
