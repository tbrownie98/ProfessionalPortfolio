﻿//Grading ID: B6295
//Program #: 4
//Due Date: 12/06/2016
//Section: CIS199-75
//Descriptiom: This program gathers inputs for a book and stores them as items in a listobx.
//             There, users can select details of the book and see if it is checked out or returned.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program4
{
    public partial class Program4 : Form
    {
        //List to hold Book objects.
        List<LibraryBook> booksList = new List<LibraryBook>();

        public Program4()
        {
            InitializeComponent();
        }

        private void addBookButton_Click(object sender, EventArgs e)
        {
            bool _Valid = true; //Holds boolean value and run through if statements for validity.
            int cr_Year; //Holds user's input for crYearTextBox in TryParse.

            //Checks if user's inputs are null fields and stores as false else stays true.
            if (string.IsNullOrEmpty(titleTextBox.Text))
            {
                MessageBox.Show("Enter a valid title!");
                _Valid = false;
            }
            if (string.IsNullOrEmpty(authorTextBox.Text))
            {
                MessageBox.Show("Enter a valid author!");
                _Valid = false;
            }
            if (string.IsNullOrEmpty(publisherTextBox.Text))
            {
                MessageBox.Show("Enter a valid publisher!");
                _Valid = false;
            }
            if (string.IsNullOrEmpty(callNumberTextBox.Text))
            {
                MessageBox.Show("Enter a valid call number!");
                _Valid = false;
            }
            if (_Valid)
            {
                if (int.TryParse(crYearTextBox.Text, out cr_Year))
                {
                    //Creates a Library Book object with user's inputs.
                    LibraryBook myBook = new LibraryBook(titleTextBox.Text,
                                                         authorTextBox.Text,
                                                         publisherTextBox.Text,
                                                         cr_Year,
                                                         callNumberTextBox.Text);
                    booksList.Add(myBook); //Adds user's book inputs to list.
                    booksListBox.Items.Add(myBook.Title); //Adds the user's book title input to booksListBox.

                    //Clear fields after book added to list and sets the focus on titleTextBox.
                    titleTextBox.Clear();
                    authorTextBox.Clear();
                    publisherTextBox.Clear();
                    crYearTextBox.Clear();
                    callNumberTextBox.Clear();
                    titleTextBox.Focus();
                }
                else
                    MessageBox.Show("Enter a valid year!");
            }
            else
                MessageBox.Show("Enter valid data into fields!");
        }

        private void detailsButton_Click(object sender, EventArgs e)
        {
            //Checks that a book title is selected in the listbox.
            if (booksListBox.SelectedIndex != -1)
                MessageBox.Show(booksList[booksListBox.SelectedIndex].ToString()); //Shows all the fields in "Details" MessageBox.
            else
                MessageBox.Show("Select a book's Title from the List!");
        }

        private void checkOutButton_Click(object sender, EventArgs e)
        {
            //Checks that a book title is selected in the listbox.
            if (booksListBox.SelectedIndex != -1)
            {
                booksList[booksListBox.SelectedIndex].CheckOut(); //Shows the bool of CheckedOut method.
                MessageBox.Show("This book has been checked out!");
            }
            else
                MessageBox.Show("Select a book's Title from the List!");
        }

        private void returnButton_Click(object sender, EventArgs e)
        {
            //Checks that a book title is selected in the listbox.
            if (booksListBox.SelectedIndex != -1)
            {
                booksList[booksListBox.SelectedIndex].ReturnToShelf(); //Shows the bool of CheckedOut method.
                MessageBox.Show("This book has been returned to the shelf.");
            }
            else
                MessageBox.Show("Select a book's Title from the List!");
        }
    }
}
