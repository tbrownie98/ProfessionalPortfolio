﻿namespace Program4
{
    partial class Program4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.authorTextBox = new System.Windows.Forms.TextBox();
            this.publisherTextBox = new System.Windows.Forms.TextBox();
            this.crYearTextBox = new System.Windows.Forms.TextBox();
            this.callNumberTextBox = new System.Windows.Forms.TextBox();
            this.booksListBox = new System.Windows.Forms.ListBox();
            this.addBookButton = new System.Windows.Forms.Button();
            this.bookDataGroupBox = new System.Windows.Forms.GroupBox();
            this.callNumberLabel = new System.Windows.Forms.Label();
            this.crYearLabel = new System.Windows.Forms.Label();
            this.publisherLabel = new System.Windows.Forms.Label();
            this.authorLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.bookListGroupBox = new System.Windows.Forms.GroupBox();
            this.returnButton = new System.Windows.Forms.Button();
            this.checkOutButton = new System.Windows.Forms.Button();
            this.detailsButton = new System.Windows.Forms.Button();
            this.bookDataGroupBox.SuspendLayout();
            this.bookListGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(91, 19);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(100, 20);
            this.titleTextBox.TabIndex = 1;
            // 
            // authorTextBox
            // 
            this.authorTextBox.Location = new System.Drawing.Point(91, 50);
            this.authorTextBox.Name = "authorTextBox";
            this.authorTextBox.Size = new System.Drawing.Size(100, 20);
            this.authorTextBox.TabIndex = 3;
            // 
            // publisherTextBox
            // 
            this.publisherTextBox.Location = new System.Drawing.Point(91, 81);
            this.publisherTextBox.Name = "publisherTextBox";
            this.publisherTextBox.Size = new System.Drawing.Size(100, 20);
            this.publisherTextBox.TabIndex = 5;
            // 
            // crYearTextBox
            // 
            this.crYearTextBox.Location = new System.Drawing.Point(91, 112);
            this.crYearTextBox.Name = "crYearTextBox";
            this.crYearTextBox.Size = new System.Drawing.Size(100, 20);
            this.crYearTextBox.TabIndex = 7;
            // 
            // callNumberTextBox
            // 
            this.callNumberTextBox.Location = new System.Drawing.Point(91, 143);
            this.callNumberTextBox.Name = "callNumberTextBox";
            this.callNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.callNumberTextBox.TabIndex = 9;
            // 
            // booksListBox
            // 
            this.booksListBox.FormattingEnabled = true;
            this.booksListBox.Location = new System.Drawing.Point(6, 19);
            this.booksListBox.Name = "booksListBox";
            this.booksListBox.Size = new System.Drawing.Size(237, 147);
            this.booksListBox.TabIndex = 0;
            // 
            // addBookButton
            // 
            this.addBookButton.Location = new System.Drawing.Point(68, 172);
            this.addBookButton.Name = "addBookButton";
            this.addBookButton.Size = new System.Drawing.Size(75, 23);
            this.addBookButton.TabIndex = 10;
            this.addBookButton.Text = "Add Book";
            this.addBookButton.UseVisualStyleBackColor = true;
            this.addBookButton.Click += new System.EventHandler(this.addBookButton_Click);
            // 
            // bookDataGroupBox
            // 
            this.bookDataGroupBox.Controls.Add(this.callNumberLabel);
            this.bookDataGroupBox.Controls.Add(this.crYearLabel);
            this.bookDataGroupBox.Controls.Add(this.publisherLabel);
            this.bookDataGroupBox.Controls.Add(this.authorLabel);
            this.bookDataGroupBox.Controls.Add(this.titleLabel);
            this.bookDataGroupBox.Controls.Add(this.titleTextBox);
            this.bookDataGroupBox.Controls.Add(this.addBookButton);
            this.bookDataGroupBox.Controls.Add(this.authorTextBox);
            this.bookDataGroupBox.Controls.Add(this.publisherTextBox);
            this.bookDataGroupBox.Controls.Add(this.callNumberTextBox);
            this.bookDataGroupBox.Controls.Add(this.crYearTextBox);
            this.bookDataGroupBox.Location = new System.Drawing.Point(12, 12);
            this.bookDataGroupBox.Name = "bookDataGroupBox";
            this.bookDataGroupBox.Size = new System.Drawing.Size(201, 202);
            this.bookDataGroupBox.TabIndex = 0;
            this.bookDataGroupBox.TabStop = false;
            this.bookDataGroupBox.Text = "Enter Book Data";
            // 
            // callNumberLabel
            // 
            this.callNumberLabel.AutoSize = true;
            this.callNumberLabel.Location = new System.Drawing.Point(18, 146);
            this.callNumberLabel.Name = "callNumberLabel";
            this.callNumberLabel.Size = new System.Drawing.Size(67, 13);
            this.callNumberLabel.TabIndex = 8;
            this.callNumberLabel.Text = "Call Number:";
            // 
            // crYearLabel
            // 
            this.crYearLabel.AutoSize = true;
            this.crYearLabel.Location = new System.Drawing.Point(6, 115);
            this.crYearLabel.Name = "crYearLabel";
            this.crYearLabel.Size = new System.Drawing.Size(79, 13);
            this.crYearLabel.TabIndex = 6;
            this.crYearLabel.Text = "Copyright Year:";
            // 
            // publisherLabel
            // 
            this.publisherLabel.AutoSize = true;
            this.publisherLabel.Location = new System.Drawing.Point(32, 84);
            this.publisherLabel.Name = "publisherLabel";
            this.publisherLabel.Size = new System.Drawing.Size(53, 13);
            this.publisherLabel.TabIndex = 4;
            this.publisherLabel.Text = "Publisher:";
            // 
            // authorLabel
            // 
            this.authorLabel.AutoSize = true;
            this.authorLabel.Location = new System.Drawing.Point(44, 53);
            this.authorLabel.Name = "authorLabel";
            this.authorLabel.Size = new System.Drawing.Size(41, 13);
            this.authorLabel.TabIndex = 2;
            this.authorLabel.Text = "Author:";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(55, 22);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(30, 13);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Title:";
            // 
            // bookListGroupBox
            // 
            this.bookListGroupBox.Controls.Add(this.returnButton);
            this.bookListGroupBox.Controls.Add(this.booksListBox);
            this.bookListGroupBox.Controls.Add(this.checkOutButton);
            this.bookListGroupBox.Controls.Add(this.detailsButton);
            this.bookListGroupBox.Location = new System.Drawing.Point(219, 12);
            this.bookListGroupBox.Name = "bookListGroupBox";
            this.bookListGroupBox.Size = new System.Drawing.Size(249, 202);
            this.bookListGroupBox.TabIndex = 1;
            this.bookListGroupBox.TabStop = false;
            this.bookListGroupBox.Text = "Select a Book";
            // 
            // returnButton
            // 
            this.returnButton.Location = new System.Drawing.Point(168, 172);
            this.returnButton.Name = "returnButton";
            this.returnButton.Size = new System.Drawing.Size(75, 23);
            this.returnButton.TabIndex = 4;
            this.returnButton.Text = "Return";
            this.returnButton.UseVisualStyleBackColor = true;
            this.returnButton.Click += new System.EventHandler(this.returnButton_Click);
            // 
            // checkOutButton
            // 
            this.checkOutButton.Location = new System.Drawing.Point(87, 172);
            this.checkOutButton.Name = "checkOutButton";
            this.checkOutButton.Size = new System.Drawing.Size(75, 23);
            this.checkOutButton.TabIndex = 3;
            this.checkOutButton.Text = "Check Out";
            this.checkOutButton.UseVisualStyleBackColor = true;
            this.checkOutButton.Click += new System.EventHandler(this.checkOutButton_Click);
            // 
            // detailsButton
            // 
            this.detailsButton.Location = new System.Drawing.Point(6, 172);
            this.detailsButton.Name = "detailsButton";
            this.detailsButton.Size = new System.Drawing.Size(75, 23);
            this.detailsButton.TabIndex = 2;
            this.detailsButton.Text = "Details";
            this.detailsButton.UseVisualStyleBackColor = true;
            this.detailsButton.Click += new System.EventHandler(this.detailsButton_Click);
            // 
            // Program4
            // 
            this.AcceptButton = this.addBookButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 224);
            this.Controls.Add(this.bookListGroupBox);
            this.Controls.Add(this.bookDataGroupBox);
            this.Name = "Program4";
            this.Text = "Program 4";
            this.bookDataGroupBox.ResumeLayout(false);
            this.bookDataGroupBox.PerformLayout();
            this.bookListGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.TextBox authorTextBox;
        private System.Windows.Forms.TextBox publisherTextBox;
        private System.Windows.Forms.TextBox crYearTextBox;
        private System.Windows.Forms.TextBox callNumberTextBox;
        private System.Windows.Forms.ListBox booksListBox;
        private System.Windows.Forms.Button addBookButton;
        private System.Windows.Forms.GroupBox bookDataGroupBox;
        private System.Windows.Forms.Label callNumberLabel;
        private System.Windows.Forms.Label crYearLabel;
        private System.Windows.Forms.Label publisherLabel;
        private System.Windows.Forms.Label authorLabel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.GroupBox bookListGroupBox;
        private System.Windows.Forms.Button detailsButton;
        private System.Windows.Forms.Button checkOutButton;
        private System.Windows.Forms.Button returnButton;
    }
}

