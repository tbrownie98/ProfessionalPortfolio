﻿//Grading ID: B6295
//Program #: 4
//Due Date: 12/06/2016
//Section: CIS199-75
//Descriptiom:  This program gathers inputs for a book and stores them as items in a listobx.
//             There, users can select details of the book and see if it is checked out or returned.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    public class LibraryBook
    {
        private int _CRYear; //_CRYEAR is assigned to a private int type.
        private bool _isCheckedOut; // _isCheckedOut is assigned to a private boolean type.
        const int DEFAULTYEAR = 2016; //Constant DEFAULTYEAR is 2016.

        public LibraryBook(string title, string author, string publisher, int cRYear, string callNumber)
        {
            Title = title; //Loading book title data 
            Author = author; //Loading book author data
            Publisher = publisher; //Loading book publisher data
            CR_Year = cRYear; //Loading book copyright year data
            CallNumber = callNumber; //Loading call number data
            _isCheckedOut = false; //Set _isCheckOut to bool type false
        }

        public string Title
        {
            //Precondition: N/A
            //Postcondition: The book's title is returned.
            get;
            //Precondition: N/A
            //Postcondition: Auto-implemented property.
            set;
        }

        public string Author
        {
            //Precondition: N/A
            //Postcondition: The book's author is returned.
            get;
            //Precondition: N/A
            //Postcondition: Auto-implemented property.
            set;
        }

        public string Publisher
        {
            //Precondition: N/A
            //Postcondition: The book's publisher is returned.
            get;
            //Precondition: N/A
            //Postcondition: Auto-implemented property.
            set;
        }

        public int CR_Year
        {
            //Precondition: N/A
            //Postcondition: The book's copyright year is returned.
            get { return _CRYear; }
            //Precondition: N/A
            //Postcondition: Auto-implemented property.
            set
            {
                if (value >= 0) //Checks for a year that is possible (non-negative).
                    _CRYear = value;
                else
                    _CRYear = DEFAULTYEAR; //Sets copyright year to 2016 if negative.
            }
        }

        public string CallNumber
        {
            //Precondition: N/A
            //Postcondition: The book's call number is returned.
            get;
            //Precondition: N/A
            //Postcondition: Auto-implemented property.
            set;
        }

        //Precondition: N/A
        //Postcondition: _isCheckedOut equals boolean true to show book is checked out.
        public void CheckOut()
        {
            _isCheckedOut = true;
        }

        //Precondition: N/A
        //Postcondition: _isCheckedOut equals boolean false to show book is on shelf.
        public void ReturnToShelf()
        {
            _isCheckedOut = false;
        }

        //Precondition: Called in by Form1 code.
        //Postcondition: The bool _isCheckedOut is returned.
        public bool IsCheckedOut()
        {
            return _isCheckedOut; //Returns _isCheckedOut when method is called upon.
        }

        //Precondition: .ToString()
        //Postcondition: Returns the format of the book's data displayed in MessageBox..
        public override string ToString()
        {
            //result is a string of the book's data organized to fit the environment.
            string result = "Title: " + Title + Environment.NewLine +
                            "Author: " + Author + Environment.NewLine +
                            "Publisher: " + Publisher + Environment.NewLine +
                            "Copyright Year: " + CR_Year + Environment.NewLine +
                            "Call Number: " + CallNumber + Environment.NewLine +
                            "Checked Out: " + IsCheckedOut();

            return result; //When called, will return book's data display.
        }
    }
}
